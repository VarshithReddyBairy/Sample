//
//  RestaurantDetailsViewController.swift
//  ActivityThree
//
//  Created by student on 4/25/22.
//

import UIKit

class RestaurantDetailsViewController: UIViewController {

    @IBOutlet weak var item1: UILabel!
    
    @IBOutlet weak var imageView: UIImageView!
    var restaurant  : RestDetails?
    
    @IBOutlet weak var item2: UILabel!
    
    @IBOutlet weak var item4: UILabel!
    
    @IBOutlet weak var item3: UILabel!
    
    @IBOutlet weak var item5: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.image = UIImage(named: (restaurant?.image)!)
        item1.text = ""
        item2.text = ""
        item3.text = ""
        item4.text = ""
        item5.text = ""
        
        
    }
    
    @IBAction func getMenu(_ sender: Any) {
        item1.text = restaurant?.item1
        item2.text = restaurant?.item2
        item3.text = restaurant?.item3
        item4.text = restaurant?.item4
        item5.text = restaurant?.item5
    }
    
    

}
