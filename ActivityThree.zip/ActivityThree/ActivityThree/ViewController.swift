//
//  ViewController.swift
//  ActivityThree
//
//  Created by student on 4/25/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var restArray :[String] = ["Apple Bees","A $ G","Simply Siams","Pizza Ranch","El Maguey"]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        restaurants.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableViewOutlet.dequeueReusableCell(withIdentifier: "restaurant", for: indexPath)
        cell.textLabel?.text = restaurants[indexPath.row].name
        return cell
    }
    

    @IBOutlet weak var tableViewOutlet: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewOutlet.delegate = self
        tableViewOutlet.dataSource = self
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "restDetails"{
            let destination = segue.destination as! RestaurantDetailsViewController
            destination.restaurant = restaurants[tableViewOutlet.indexPathForSelectedRow!.row].details
        }
    }

}

